#ifndef _STUDENT_H
#define _STUDENT_H

#include<string>

using namespace std;

struct Student
{
	int id;
	int age;
	bool sex;
	string name;
	Student& operator=(const Student& other);

};

void studentPrint(Student &s);

#endif
