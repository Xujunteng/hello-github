#include "Student.h"
#include <iostream>

using namespace std;

Student& Student::operator=(const Student& other) {
    if (this == &other)
        return *this;
    id = other.id;
    age = other.age;
    sex = other.sex;
    name = other.name;
    return *this;
}
void studentPrint(Student &s)
{
    cout << "ID: " << s.id << ", age: " << s.age << ", sex: " << (s.sex ? 'M' : 'F') << endl;
}
