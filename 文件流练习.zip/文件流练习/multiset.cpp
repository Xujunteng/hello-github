﻿#include <fstream>
#include <string>
#include <set>
#include<algorithm>
using namespace std;

int main()
{
	multiset<string> ms;
	ifstream inFile("names.txt");
	ofstream outFile("output.txt");
	string txtLine;
	while (getline(inFile, txtLine))
	{
		ms.insert(txtLine);
		//请填写程序
	}
	int i = 1;
	for (const string& x : ms) {
		outFile <<i++<<"." << x << endl;
	}
	//请填写程序
	inFile.close();
	outFile.close();
	return 0;
}
